var cnv; 
var d; 
var g; 
function setup() {
  cnv = createCanvas(300, 500);
}

function draw() {
  if (mouseIsPressed) {
    fill(0);
  } else {
    fill(255);
  }
  ellipse(mouseX, mouseY, 80, 80);
}